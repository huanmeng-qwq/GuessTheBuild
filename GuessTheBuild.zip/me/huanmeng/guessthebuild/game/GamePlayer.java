package me.huanmeng.guessthebuild.game;

import lombok.Getter;
import lombok.Setter;
import me.huanmeng.guessthebuild.GuesstheBuild;
import me.huanmeng.guessthebuild.SQL;
import me.huanmeng.guessthebuild.database.DataBase;
import me.huanmeng.guessthebuild.database.KeyValue;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Getter
@Setter
public class GamePlayer {
    private static List<GamePlayer> players=new ArrayList<>();
    private PlayerStatus status;
    private Player player;
    private UUID uuid;
    private String name;
    private String prefix;
    private int score;
    private int sqlScore;
    private boolean theme=false;
    private int win;
    private DataBase database= GuesstheBuild.getDataBase();
    public GamePlayer(UUID uuid){
        this.uuid=uuid;
        this.player= Bukkit.getPlayer(uuid);
        this.status=PlayerStatus.GUESS;
        this.name=player.getDisplayName();
        prefix="&8未经雕琢";
        score=0;
        players.add(this);
        init();
    }

    public void init(){
        if (database.isValueExists(SQL.TABLE_DATA, SQL.KV_DATA, new KeyValue("uuid", getUuid().toString()))) {
            this.sqlScore = Integer.parseInt(database.dbSelectFirst(SQL.TABLE_DATA, "score", new KeyValue("uuid", uuid.toString())));
            this.win = Integer.parseInt(database.dbSelectFirst(SQL.TABLE_DATA, "win", new KeyValue("uuid", uuid.toString())));
        } else {
            win=0;
            score = 0;
            database.dbInsert(SQL.TABLE_DATA, new KeyValue("uuid", uuid.toString()).add("win", 0).add("score", 0));
        }
        if(sqlScore>=0){
            prefix="§f初来乍到";
        }
        if(sqlScore>=100){
            prefix="§8未经雕琢";
        }
        if(sqlScore>=250){
            prefix="§e初窥门径";
        }
        if(sqlScore>=500){
            prefix="§a学有所成";
        }
        if(sqlScore>=1000){
            prefix="§d驾轻就熟";
        }
        if(sqlScore>=2000){
            prefix="§9历练老成";
        }
        if(sqlScore>=3500){
            prefix="§2技艺精湛";
        }
        if(sqlScore>=5000){
            prefix="§3炉火纯青";
        }
        if(sqlScore>=7500){
            prefix="§c技惊四座";
        }
        if(sqlScore>=15000){
            prefix="§1闻名于世";
        }
        if(sqlScore>=20000){
            prefix="§c名垂青史";
        }

    }

    public void sendMessage(String... message){
        if(Bukkit.getPlayer(uuid)==null)return;
        setPlayer(Bukkit.getPlayer(uuid));
        for (String s : message) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',s));
        }
    }
    public static GamePlayer get(UUID uuid){
//        return players.stream().filter(g->g.getUuid()==uuid).collect(Collectors.toList()).get(0);
        for (GamePlayer player : players) {
            if(player.getUuid()==uuid){
                return player;
            }
        }
        return null;
    }
    public void giveScore(int amount){
        score+=amount;
        sqlScore+=amount+10;
        database.dbUpdate(SQL.TABLE_DATA, new KeyValue("score", this.sqlScore), new KeyValue("uuid", this.getUuid().toString()));
    }
    public void giveWin(int amount){
        win+=amount;
        database.dbUpdate(SQL.TABLE_DATA, new KeyValue("win", this.win), new KeyValue("uuid", this.getUuid().toString()));
    }
}
