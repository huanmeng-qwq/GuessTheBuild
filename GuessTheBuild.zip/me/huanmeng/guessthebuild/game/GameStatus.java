package me.huanmeng.guessthebuild.game;

public enum GameStatus {
    WAIT,GAMING,FINISH;
}
