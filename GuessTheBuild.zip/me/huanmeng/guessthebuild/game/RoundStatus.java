package me.huanmeng.guessthebuild.game;

/**
 * 作者 huanmeng_qwq<br>
 * 2020/9/24<br>
 * GuesstheBuild
 */
public enum RoundStatus {
    BUILD,SELECT,FINISH;
}
