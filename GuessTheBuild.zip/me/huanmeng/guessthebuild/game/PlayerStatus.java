package me.huanmeng.guessthebuild.game;

public enum PlayerStatus {
    GUESS,BUILD;
}
