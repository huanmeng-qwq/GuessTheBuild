package me.huanmeng.guessthebuild.game;

public class BuildTheGuessException extends Exception {
    public BuildTheGuessException(String message) {
        super(message);
    }
}
