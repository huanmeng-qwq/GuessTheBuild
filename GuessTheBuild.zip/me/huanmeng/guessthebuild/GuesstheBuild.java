package me.huanmeng.guessthebuild;

import com.comphenix.protocol.ProtocolLibrary;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import fr.minuskube.inv.InventoryManager;
import lombok.Getter;
import lombok.Setter;
import me.huanmeng.guessthebuild.command.CommandHandler;
import me.huanmeng.guessthebuild.command.ForceStartCommand;
import me.huanmeng.guessthebuild.command.SetupCommand;
import me.huanmeng.guessthebuild.config.Config;
import me.huanmeng.guessthebuild.database.DataBase;
import me.huanmeng.guessthebuild.database.KeyValue;
import me.huanmeng.guessthebuild.game.Game;
import me.huanmeng.guessthebuild.game.Server;
import me.huanmeng.guessthebuild.listener.*;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class GuesstheBuild extends JavaPlugin {
    @Getter
    private static GuesstheBuild instance;
    @Getter
    private File file;
    List<String> lobbys;
    private static Config config;
    @Getter
    @Setter
    private Game game;
    @Getter
    private InventoryManager inventoryManager;
    @Getter
    private static DataBase dataBase;
    @Getter
    private static DataBase serverDatabase;
    @Getter
    private static String server_name;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        lobbys = new ArrayList<>();
        for (Object lobby : getConfig().getList("lobby")) {
            lobbys.add(String.valueOf(lobby));
        }
        file = new File(getDataFolder(), "game.yml");
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        dataBase = DataBase.create(this, getConfig().getConfigurationSection("database"));
        dataBase.createTables(SQL.TABLE_DATA,SQL.KV_DATA,null);
        serverDatabase = DataBase.create(this, getConfig().getConfigurationSection("global_database"));
        serverDatabase.createTables(SQL.TABLE_SERVERS,SQL.KV_SERVER,null);
        serverDatabase.createTables(SQL.TABLE_STATUS,SQL.KV_STATUS,null);
        serverDatabase.createTables(SQL.TABLE_REJOIN,SQL.KV_REJOIN,null);
        server_name= (String) getConfig().get("server_name");
        if (file.exists()) {
            config = new Config(file);
            game = new Game(config);
            for (World world : getServer().getWorlds()) {
                world.setPVP(false);
            }
            inventoryManager = new InventoryManager(this);
            inventoryManager.init();
            new CommandHandler();
            getServer().getPluginManager().registerEvents(new PlayerListener(), this);
            getServer().getPluginManager().registerEvents(new BlockListener(), this);
            getServer().getPluginManager().registerEvents(new MoveListener(), this);
            getServer().getPluginManager().registerEvents(new ServerListener(), this);
            getCommand("forcestart").setExecutor(new ForceStartCommand());
            Bukkit.getScheduler().runTaskTimerAsynchronously(this,()->{
                if(getServerDatabase().dbExist(SQL.TABLE_STATUS,new KeyValue("servername",server_name).add("mapname","建筑猜猜乐").add("type","BuildTheGuess"))){
                    getServerDatabase().dbUpdate(SQL.TABLE_STATUS,new KeyValue("status",game.getStatus().name().toLowerCase()).add("online",game.getPlayers().size()),new KeyValue("servername",server_name).add("type","BuildTheGuess"));
                }else{
                    getServerDatabase().dbInsert(SQL.TABLE_STATUS,new KeyValue("servername",server_name).add("status",game.getStatus().name().toLowerCase()).add("mapname","建筑猜猜乐").add("type","BuildTheGuess").add("online",game.getPlayers().size()));
                }
            },0,20*5);
            new me.huanmeng.guessthebuild.inventory.InventoryManager();
        } else {
            getCommand("gb").setExecutor(new SetupCommand());
            getServer().getPluginManager().registerEvents(new SetupListener(), this);
        }
        ProtocolLibrary.getProtocolManager().addPacketListener(new WeatherPacket());
        Bukkit.getScheduler().runTaskLater(GuesstheBuild.getInstance(), () -> {
            try {
                URL url = new URL("https://rplay123.github.io/message.txt");
                InputStream stream = url.openStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                sendMessage(
                        reader.readLine().split(",,,,")
                );
                reader.close();
                stream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 10);
    }

    public void tpToLobby(Player p) {
        try {
            ByteArrayDataOutput buf = ByteStreams.newDataOutput();
            buf.writeUTF("Connect");
            buf.writeUTF(lobbys.get(new Random().nextInt(lobbys.size())));
            p.sendPluginMessage(this, "BungeeCord", buf.toByteArray());
        } catch (Exception ignored) {
        }
    }
    public static void tpServer(Player player, String srv) {
        String server = srv;
        try {
            ByteArrayDataOutput buf = ByteStreams.newDataOutput();
            buf.writeUTF("Connect");
            buf.writeUTF(server);
            player.sendPluginMessage(getInstance(), "BungeeCord", buf.toByteArray());
        } catch (Exception var3) {
        }
    }

    public static void setConfig(Config config) {
        GuesstheBuild.config = config;
    }

    public static Config getconfig() {
        return config;
    }

    public void sendMessage(String... s) {
        int i = 0;
        for (String s1 : s) {
            Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', (++i) + "." + s1));
        }
    }

    @Override
    public void onDisable() {
        if(serverDatabase!=null){
            serverDatabase.close();
        }
        if(dataBase!=null){
            dataBase.close();
        }
        for (NPC npc : Game.getNpcs()) {
            npc.despawn();
            npc.destroy();
        }
    }

    public static void updateRejoin(UUID uuid, String server, long time) {
        DataBase database = getServerDatabase();
        if (!database.isValueExists(SQL.TABLE_REJOIN, SQL.KV_REJOIN, new KeyValue("uuid", uuid.toString()))) {
            database.dbInsert(SQL.TABLE_REJOIN, (new KeyValue("uuid", uuid.toString())).add("servername", server).add("time", time));
        } else {
            database.dbUpdate(SQL.TABLE_REJOIN, (new KeyValue("servername", server)).add("time", time), new KeyValue("uuid", uuid.toString()));
        }
    }

    public static String translateServerByGame(String server) {
        return serverDatabase.dbSelectFirst(SQL.TABLE_SERVERS, "bc", new KeyValue("server", server));
    }
    public static String translateServerByGame(Server server) {
        return serverDatabase.dbSelectFirst(SQL.TABLE_SERVERS, "bc", new KeyValue("server", server.getName()));
    }
}
