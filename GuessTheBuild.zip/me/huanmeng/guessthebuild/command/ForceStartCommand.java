package me.huanmeng.guessthebuild.command;

import me.huanmeng.guessthebuild.game.Game;
import me.huanmeng.guessthebuild.game.GameStatus;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 * 作者 huanmeng_qwq<br>
 * 2020/9/24<br>
 * GuesstheBuild
 */
public class ForceStartCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(sender.hasPermission("guessthebuild.forcestart")){
            if(Game.getInstance()==null){
                sender.sendMessage("§c未找到游戏实例,请配置完重启");
                return true;
            }
            if(Game.getInstance().getStatus()== GameStatus.WAIT){
                Game.getInstance().start();
            }else{
                sender.sendMessage("§c游戏已经开始了!");
            }
        }
        return true;
    }
}
