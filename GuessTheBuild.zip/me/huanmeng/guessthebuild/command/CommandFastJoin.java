package me.huanmeng.guessthebuild.command;
/*
 * @Author huanmeng_qwq
 * @Date 2020/8/22 21:26
 * Bedwars
 */

import me.huanmeng.guessthebuild.GuesstheBuild;
import me.huanmeng.guessthebuild.game.Server;
import me.huanmeng.guessthebuild.inventory.InventoryManager;
import me.huanmeng.guessthebuild.inventory.MatchServerMenu;
import org.bukkit.command.CommandException;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.*;

@SuppressWarnings("all")
public class CommandFastJoin extends BaseCommand {
    public CommandFastJoin() {
        super("fastjoin");
        setPermission("guessthebuild.fastjoin");
    }

    public CommandFastJoin(String name) {
        super(name);
    }

    @Override
    public String getPossibleArguments() {
        return null;
    }

    @Override
    public int getMinimumArguments() {
        return 0;
    }

    @Override
    public void execute(CommandSender sender, String label, String[] args) throws CommandException {
        if (args.length == 0) {
            GuesstheBuild.tpServer(((Player) sender), GuesstheBuild.translateServerByGame(fastJoin()));
        } else if (args.length == 1 && args[0].equalsIgnoreCase("gui")) {
            InventoryManager.MATCHSERVERMENU.open(((Player) sender));
        }
    }

    @Override
    public boolean isOnlyPlayerExecutable() {
        return true;
    }

    public static Server fastJoin() {
        HashMap<Server,Integer> slist = new HashMap<>();
        List<Server> sorted=new ArrayList<>();
        for (Server server : MatchServerMenu.getWaitServer()) {
            slist.put(server,server.getOnline());
        }
        List<Map.Entry<Server,Integer>> maplist = new ArrayList<Map.Entry<Server, Integer>>(slist.entrySet());
        Collections.sort(maplist, new Comparator<Map.Entry<Server, Integer>>() {
            @Override
            public int compare(Map.Entry<Server, Integer> o1, Map.Entry<Server, Integer> o2) {
                return o2.getValue() - o1.getValue();
            }
        });
        LinkedHashMap<String, Integer> s = new LinkedHashMap<String, Integer>();
        List<Server> ser = new ArrayList<>();
        for (int i = 0; i < maplist.size(); i++) {
            Map.Entry<Server, Integer> x = maplist.get(i);
            sorted.add(x.getKey());
        }
        return sorted.get(0);
    }
}
