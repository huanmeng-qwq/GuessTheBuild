package me.huanmeng.guessthebuild.command;

import me.huanmeng.guessthebuild.inventory.InventoryManager;
import org.bukkit.command.CommandException;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * 作者 huanmeng_qwq<br>
 * 2020/9/25<br>
 * GuesstheBuild
 */
public class CommandDebug extends BaseCommand {
    public CommandDebug() {
        super("debug");
        setPermission("guessthebuild.admin");
    }

    @Override
    public String getPossibleArguments() {
        return null;
    }

    @Override
    public int getMinimumArguments() {
        return 0;
    }

    @Override
    public void execute(CommandSender sender, String label, String[] args) throws CommandException {
        if(args.length==0){
            InventoryManager.FE.open(((Player) sender));
        }
    }

    @Override
    public boolean isOnlyPlayerExecutable() {
        return true;
    }
}
