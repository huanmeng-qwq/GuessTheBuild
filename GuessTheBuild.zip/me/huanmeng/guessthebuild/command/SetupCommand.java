package me.huanmeng.guessthebuild.command;

import me.huanmeng.guessthebuild.GuesstheBuild;
import me.huanmeng.guessthebuild.config.Config;
import me.huanmeng.guessthebuild.game.Region;
import me.huanmeng.guessthebuild.game.Theme;
import me.huanmeng.guessthebuild.game.ThemeDifficulty;
import me.huanmeng.guessthebuild.listener.SetupListener;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author huanmeng_qwq
 * 2020/9/23
 * GuesstheBuild
 */
public class SetupCommand implements CommandExecutor {
    private static List<Region> regions = new ArrayList<>();
    private static List<Theme> themes = new ArrayList<>();
    private static List<Location> locs=new ArrayList<>();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!GuesstheBuild.getInstance().getFile().exists()) {
            try {
                GuesstheBuild.getInstance().getFile().createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
            GuesstheBuild.setConfig(new Config(GuesstheBuild.getInstance().getFile()));
        }
        Config config = GuesstheBuild.getconfig();
        if (sender instanceof Player) {
            if (args.length == 0) {
                sendmsg(sender, "&a/" + label + " ",
                        "setlobby",
                        "setmaxplayer <int>",
                        "addregion #中间位置将设置你所在的位置",
                        "addnpc",
                        "addtheme <Difficulty> <String>",
                        "flaty [int]",
                        "info"
                );
                sendmsg(sender, "&a", "Theme Difficulty");
                for (ThemeDifficulty value : ThemeDifficulty.values()) {
                    sendmsg(sender, "&a", "  " + value.getColor() + value.name());
                }
                return true;
            }
            if (args.length == 1) {
                switch (args[0].toLowerCase()) {
                    case "setlobby":
                        config.setLocation("lobby", ((Player) sender).getLocation());
                        m(sender, "&a设置成功");
                        break;
                    case "setmaxplayer":
                        config.set("max", 10);
                        m(sender, "&a设置成功", "&emax: 10");
                        break;
                    case "addregion":
                        if (SetupListener.left == null || SetupListener.right == null) {
                            m(sender, "&cUnKnow Region Set!");
                            return true;
                        }
                        config.setLocation("regions." + (regions.size() + 1) + ".min", SetupListener.left);
                        config.setLocation("regions." + (regions.size() + 1) + ".max", SetupListener.right);
                        config.setLocation("regions." + (regions.size() + 1) + ".middle", ((Player) sender).getLocation());
                        regions.add(new Region(SetupListener.left, SetupListener.right, ((Player) sender).getLocation()));
                        m(sender, "&a添加成功#" + regions.size());
                        break;
                    case "info":
                        sendmsg(sender, "&a", "区域已设置&b" + regions.size() + "&a个");
                        sendmsg(sender, "&a", "主题已设置&b" + themes.size() + "&a个");
                        themes.forEach(t -> sendmsg(sender, "&a", t.getName()));
                    case "flaty":
                        config.set("flatY",((Player) sender).getLocation().getBlockY());
                        sendmsg(sender, "&a", "已设置平面Y轴为" + ((Player) sender).getLocation().getBlockY());
                    case "addnpc":
                        config.setLocation("npcs."+(locs.size()+1)+".loc", ((Player) sender).getLocation());
                        locs.add(((Player) sender).getLocation());
                        m(sender, "&a添加&bNPC&a成功#" + locs.size());
                    default:
                        return true;
                }
            }
            if (args.length == 2) {
                switch (args[0].toLowerCase()) {
                    case "setmaxplayer":
                        try {
                            Integer.parseInt(args[1]);
                        } catch (NumberFormatException e) {
                            m(sender, "&cUnkNow Number!");
                            return true;
                        }
                        config.set("max", Integer.parseInt(args[1]));
                        m(sender, "&a设置成功", "&emax: " + args[1]);
                        break;
                    case "flaty":
                        try {
                            if (Integer.parseInt(args[0]) > 256) {
                                sendmsg(sender, "&a", "&c>256");
                                return true;
                            }
                            config.set("flatY", Integer.parseInt(args[1]));
                        } catch (NumberFormatException e) {
                            sendmsg(sender, "&a", "&cUnKnow Number");
                            return true;
                        }
                        sendmsg(sender, "&a", "已设置平面Y轴为" + args[1]);
                    default:
                        return true;
                }
            }
            if (args.length == 3) {
                switch (args[0].toLowerCase()) {
                    case "addtheme":
                        config.set("themes." + (themes.size() + 1) + ".difficulty", args[1].toUpperCase());
                        config.set("themes." + (themes.size() + 1) + ".name", args[2]);
                        try {
                            themes.add(new Theme(ThemeDifficulty.valueOf(args[1].toUpperCase()), args[2]));
                        } catch (IllegalArgumentException e) {
                            m(sender, "&c未知难度: " + args[1]);
                            return true;
                        }
                        m(sender, "&a添加主题成功#" + themes.size());
                        break;
                }
            }
        }
        return true;
    }

    public void sendmsg(CommandSender sender, String prefix, String... message) {
        for (String s : message) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', prefix + s));
        }
    }

    public void m(CommandSender sender, String... m) {
        sendmsg(sender, "", m);
    }
}
