package me.huanmeng.guessthebuild.task;


import me.huanmeng.guessthebuild.GuesstheBuild;
import me.huanmeng.guessthebuild.game.*;
import me.huanmeng.guessthebuild.utils.LuckPerms;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.scheduler.BukkitRunnable;

import java.text.SimpleDateFormat;
import java.util.*;

public class ScoreboardTask extends BukkitRunnable {
    public static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
    @Override
    public void run() {
        Game game = Game.getInstance();

        if (game != null) {
            if (game.getStatus() == GameStatus.WAIT) {
                for (GamePlayer gamePlayer : game.getOnlinePlayers()) {
                    _displayWaiting(gamePlayer, game);
                }
            } else if (game.getStatus() == GameStatus.GAMING) {
                for (GamePlayer gamePlayer : game.getOnlinePlayers()) {
                    _displayGaming(gamePlayer, game);
                }
            }else if(game.getStatus()==GameStatus.FINISH){
                for (GamePlayer onlinePlayer : game.getOnlinePlayers()) {
                    displayFinishing(onlinePlayer,game);
                }
            }
        }
    }
    private void displayFinishing(GamePlayer gamePlayer,Game game){
        List<String> strings = new ArrayList<String>(){
            @Override
            public boolean add(String s) {
                return super.add(ChatColor.translateAlternateColorCodes('&',s));
            }
        };
        List<GamePlayer> sorted=new ArrayList<>(game.getPlayers());
        sorted.sort(new Comparator<GamePlayer>() {
            @Override
            public int compare(GamePlayer o1, GamePlayer o2) {
                return Integer.compare(o2.getScore(), o1.getScore());
            }
        });
        strings.add("&e建筑猜猜乐");
        strings.add("&7"+dateFormat.format(new Date())+"  §8"+ GuesstheBuild.getServer_name());
        strings.add("&a");
        for (int i = 0; i < sorted.size(); i++) {
            strings.add("&e"+(i+1)+". "+ (Bukkit.getPlayer(sorted.get(i).getUuid())!=null?LuckPerms.getRank(sorted.get(i).getPlayer())+sorted.get(i).getName()+"&f: &a"+sorted.get(i).getScore():"&7"+sorted.get(i).getName()+"&f: &a"+sorted.get(i).getScore()));
        }
        strings.add("&c");
        strings.add("§e§lHyCraft");
        ScoreboardUtil.unrankedSidebarDisplay(gamePlayer.getPlayer(), strings.toArray(new String[strings.size()]));
    }

    private void _displayWaiting(GamePlayer gamePlayer, Game game) {
        List<String> strings = new ArrayList<String>(){
            @Override
            public boolean add(String s) {
                return super.add(ChatColor.translateAlternateColorCodes('&',s));
            }
        };
        strings.addAll(Arrays.asList(
                "§e§l建筑猜猜乐",
                "§7"+dateFormat.format(new Date())+"  §8"+ GuesstheBuild.getServer_name(),
                ChatColor.BLACK + "§1",
                "§f玩家:§a " + game.getPlayers().size() + "/" + game.getMax(),
                ChatColor.DARK_GRAY + " "
        ));
        if (game.getPlayers().size() >= 3) {
            strings.add("§f即将于§a" + getFormattedTime(game.getWaitTime()) + "§f开始");
            strings.add("§f以允许更多");
            strings.add("§f玩家加入");
        } else {
            strings.add("§f倒计时: §a" + getFormattedTime(game.getWaitTime()));
            strings.add("§f需要玩家: §a" + (3 - game.getPlayers().size()));
        }
        strings.add("§f§f§1");
        strings.add("§f模式: &a建筑猜猜乐");
        strings.add("§f§2");
        strings.add("§e§lHyCraft");

        ScoreboardUtil.unrankedSidebarDisplay(gamePlayer.getPlayer(), strings.toArray(new String[strings.size()]));
    }

    private void _displayGaming(GamePlayer gamePlayer, Game game) {
        List<String> strings = new ArrayList<String>(){
            @Override
            public boolean add(String s) {
                return super.add(ChatColor.translateAlternateColorCodes('&',s));
            }
        };
        strings.addAll(Arrays.asList(
                "§e§l建筑猜猜乐",
                "§7"+dateFormat.format(new Date())+"  §8"+ GuesstheBuild.getServer_name()
        ));
        strings.add("§f建筑师:");
        strings.add(" " + (game.getBuilder().getPlayer().getName().equalsIgnoreCase(game.getBuilder().getName()) ? LuckPerms.getPrefix(game.getBuilder().getPlayer()) + game.getBuilder().getName() : game.getBuilder().getName()));
        strings.add("§a");
//        strings.add(game.getScoreTop().get(0));
        strings.add((game.getScoreTop().get(0).getPlayer().getName().equalsIgnoreCase(game.getScoreTop().get(0).getName()) ? LuckPerms.getPrefix(game.getScoreTop().get(0).getPlayer()) + game.getScoreTop().get(0).getName() : game.getScoreTop().get(0).getName()) + "&f: &a" + game.getScoreTop().get(0).getScore());
        strings.add((game.getScoreTop().get(1).getPlayer().getName().equalsIgnoreCase(game.getScoreTop().get(1).getName()) ? LuckPerms.getPrefix(game.getScoreTop().get(1).getPlayer()) + game.getScoreTop().get(1).getName() : game.getScoreTop().get(1).getName()) + "&f: &a" + game.getScoreTop().get(1).getScore());
        strings.add((game.getScoreTop().get(2).getPlayer().getName().equalsIgnoreCase(game.getScoreTop().get(2).getName()) ? LuckPerms.getPrefix(game.getScoreTop().get(2).getPlayer()) + game.getScoreTop().get(2).getName() : game.getScoreTop().get(2).getName()) + "&f: &a" + game.getScoreTop().get(2).getScore());
        if (game.getPlayers().size() > 3) {
            strings.add("§f...");
            strings.add((gamePlayer.getPlayer().getName().equalsIgnoreCase(gamePlayer.getName()) ? LuckPerms.getPrefix(gamePlayer.getPlayer()) + gamePlayer.getName() : gamePlayer.getName()));
        }
        strings.add((RoundManager.getRound().getRoundStatus()== RoundStatus.SELECT ? "§f开始于: §a" + getFormattedTime(RoundManager.getRound().getSelectTime()) : "§f时间: §a" + getFormattedTime(RoundManager.getRound().getSecond())));
        strings.add("§f§f");
        strings.add("§f主题:");
        if (gamePlayer.isTheme()) {
            strings.add(" "+(RoundManager.getRound().getSelectTheme()==null?"&a请选择":"&b"+RoundManager.getRound().getSelectTheme().name));
        } else {
//            strings.add(" " + (!gamePlayer.isTheme() || RoundManager.getRound().getSelectTheme() == null ? "§d???" : game.getRoundTask().getTheme().getName()));
            if(RoundManager.getRound().getSecond()>=90){
                strings.add(" §c???");
            }
            if(RoundManager.getRound().getSecond()<90){
                strings.add(" §a"+RoundManager.getRound().getPrompt());
            }
        }
        strings.add("§e§lHyCraft");
        ScoreboardUtil.unrankedSidebarDisplay(gamePlayer.getPlayer(), strings.toArray(new String[strings.size()]));
    }

    public static String getFormattedTime(int time) {
        int min = (int) Math.floor(time / 60);
        int sec = time % 60;
        String minStr = min < 10 ? "0" + min : String.valueOf(min);
        String secStr = sec < 10 ? "0" + sec : String.valueOf(sec);
        return minStr + ":" + secStr;
    }
}
