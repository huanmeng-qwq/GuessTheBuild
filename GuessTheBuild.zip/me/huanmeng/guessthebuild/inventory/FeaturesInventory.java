package me.huanmeng.guessthebuild.inventory;

import fr.minuskube.inv.ClickableItem;
import fr.minuskube.inv.SmartInventory;
import fr.minuskube.inv.content.InventoryContents;
import fr.minuskube.inv.content.InventoryProvider;
import me.huanmeng.guessthebuild.game.*;
import me.huanmeng.guessthebuild.game.WeatherType;
import me.huanmeng.guessthebuild.utils.ItemBuilder;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.*;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;

/**
 * 作者 huanmeng_qwq<br>
 * 2020/9/25<br>
 * GuesstheBuild
 */
public class FeaturesInventory {
    public static SmartInventory Features(){
        SmartInventory.Builder builder=SmartInventory.builder();
        builder.size(4,9);
        builder.title("更多功能");
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                contents.set(1,2, ClickableItem.of(new ItemBuilder(Material.YELLOW_FLOWER).setDisplayName("&a领地天气").addLore("&7更改领地的&a天气").build(),e->{
                    InventoryManager.FE_WEATHER.open(player);
                }));
                contents.set(1,3, ClickableItem.of(new ItemBuilder(Material.WATCH).setDisplayName("&a领地时间").addLore("&7更改领地的&a时间").build(),e->{
                    InventoryManager.FE_TIME.open(player);
                }));
                contents.set(1,5, ClickableItem.of(new ItemBuilder(Material.EMPTY_MAP).setDisplayName("&a领地群系").addLore("&7更改领地的群系").build(),e->{
                    InventoryManager.FE_BIOME.open(player);
                }));
                contents.set(1,6, ClickableItem.of(new ItemBuilder(RoundManager.getRound().getType().getType()).setDisplayName("&a领地地表").addLore("&7更改领地地表的&a方块").build(),e->{
                    if(e.getWhoClicked().getItemOnCursor()!=null&&e.getWhoClicked().getItemOnCursor().getType()!=Material.AIR&&(e.getWhoClicked().getItemOnCursor().getType().isBlock()||e.getWhoClicked().getItemOnCursor().getType().name().endsWith("BUCKET"))){
                        RoundManager.getRound().setType(e.getWhoClicked().getItemOnCursor());
                        sendMessage(player,"&a设置成功！");
                        player.closeInventory();
                    }
                }));
                contents.set(2,4,ClickableItem.of(new ItemBuilder(Material.BANNER).setDisplayName("&a旗帜制作器").build(),e->{
                    buildBannerColor(new ItemStack(Material.BANNER,1, (short) 15)).open(player);
                }));

            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }
    public static SmartInventory Weather(){
        SmartInventory.Builder builder=SmartInventory.builder();
        builder.title("更改天气").size(4,9).parent(InventoryManager.FE);
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                contents.set(1,2,ClickableItem.of(new ItemBuilder(Material.BLAZE_ROD).setDisplayName("&e风暴").addLore("&7将天气设置为&a风暴").build(),e->{
                    RoundManager.getRound().setWeatherType(WeatherType.THUNDER);
                    sendMessage(player,"&e已将天气设置为&a风暴");
                }));
                contents.set(1,3,ClickableItem.of(new ItemBuilder(Material.WATER_BUCKET).setDisplayName("&e雨天").addLore("&7将天气设置为&a雨天").build(),e->{
                    RoundManager.getRound().setWeatherType(WeatherType.DOWNFALL);
                    sendMessage(player,"&e已将天气设置为&a雨天");
                }));
                contents.set(1,4,ClickableItem.of(new ItemBuilder(Material.SNOW_BALL).setDisplayName("&e下雪").addLore("&7将天气设置为&a下雪").build(),e->{
                    RoundManager.getRound().setWeatherType(WeatherType.SNOW);
                    sendMessage(player,"&e已将天气设置为&a下雪");
                }));
                contents.set(1,5,ClickableItem.of(new ItemBuilder(Material.YELLOW_FLOWER).setDisplayName("&e晴天").addLore("&7将天气设置为&a晴天").build(),e->{
                    RoundManager.getRound().setWeatherType(WeatherType.CLEAR);
                    sendMessage(player,"&e已将天气设置为&a晴天");
                }));
                contents.set(3,4,ClickableItem.of(new ItemBuilder(Material.ARROW).setDisplayName("&a返回").addLore("&7至领地选项").build(), e->{
                    builder.getParent().open(player);
                }));
            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }
    public static SmartInventory Time(){
        SmartInventory.Builder builder=SmartInventory.builder();
        builder.title("更改时间").size(4,9).parent(InventoryManager.FE);
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                contents.set(1,2,ClickableItem.of(new ItemBuilder(Material.STAINED_CLAY,1, (byte) 14).setDisplayName("&e凌晨").addLore("&7将设置为&a凌晨").build(),e->{
                    RoundManager.getRound().setTime(500);
                }));
                contents.set(1,3,ClickableItem.of(new ItemBuilder(Material.STAINED_CLAY,1, (byte) 14).setDisplayName("&e上午").addLore("&7将设置为&a上午").build(),e->{
                    RoundManager.getRound().setTime(900);
                }));
                contents.set(1,4,ClickableItem.of(new ItemBuilder(Material.STAINED_CLAY,1, (byte) 1).setDisplayName("&e中午").addLore("&7将设置为&a中午").build(),e->{
                    RoundManager.getRound().setTime(6000);
                }));
                contents.set(1,5,ClickableItem.of(new ItemBuilder(Material.STAINED_CLAY,1, (byte) 13).setDisplayName("&e傍晚").addLore("&7将设置为&a傍晚").build(),e->{
                    RoundManager.getRound().setTime(13500);
                }));
                contents.set(1,6,ClickableItem.of(new ItemBuilder(Material.STAINED_CLAY,1, (byte) 13).setDisplayName("&e午夜").addLore("&7将设置为&a午夜").build(),e->{
                    RoundManager.getRound().setTime(18000);
                }));
                contents.set(3,4,ClickableItem.of(new ItemBuilder(Material.ARROW).setDisplayName("&a返回").addLore("&7至领地选项").build(), e->{
                    builder.getParent().open(player);
                }));

            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }
    public static SmartInventory Biome(){
        SmartInventory.Builder builder= SmartInventory.builder();
        builder.parent(Features()).size(4,9).parent(InventoryManager.FE);
        Biome biome=RoundManager.getRound()==null||RoundManager.getRound().getBiome()==null?Biome.PLAINS:RoundManager.getRound().getBiome();
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                contents.set(0,0,ClickableItem.of(new ItemBuilder(Material.GRASS).setDisplayName("&e平原").addLore("&7将生物群戏设置为&a平原","",(biome!=Biome.PLAINS?"&e点击选择！":"&a已选择")).build(),e->{
                    RoundManager.getRound().setBiome(Biome.PLAINS);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,1,ClickableItem.of(new ItemBuilder(Material.SANDSTONE,1, (byte) 1).setDisplayName("&e平顶山").addLore("&7将生物群戏设置为&a平顶山","",(biome!=Biome.MESA?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.MESA);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,2,ClickableItem.of(new ItemBuilder(Material.WATER_BUCKET).setDisplayName("&e海洋").addLore("&7将生物群戏设置为&a海洋","",(biome!=Biome.OCEAN?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.OCEAN);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,3,ClickableItem.of(new ItemBuilder(Material.SAND).setDisplayName("&e沙漠").addLore("&7将生物群戏设置为&a沙漠","",(biome!=Biome.DESERT?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.DESERT);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,4,ClickableItem.of(new ItemBuilder(Material.LOG).setDisplayName("&e森林").addLore("&7将生物群戏设置为&a森林","",(biome!=Biome.FOREST?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.FOREST);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,5,ClickableItem.of(new ItemBuilder(Material.VINE).setDisplayName("&a丛林").addLore("&7将生物群戏设置为&a丛林","",(biome!=Biome.JUNGLE?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.JUNGLE);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,6,ClickableItem.of(new ItemBuilder(Material.ICE).setDisplayName("&e冰原").addLore("&7将生物群戏设置为&a冰原","",(biome!=Biome.ICE_PLAINS?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.ICE_PLAINS);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,7,ClickableItem.of(new ItemBuilder(Material.WATER_LILY).setDisplayName("&e沼泽").addLore("&7将生物群戏设置为&a沼泽","",(biome!=Biome.SWAMPLAND?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.SWAMPLAND);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(0,8,ClickableItem.of(new ItemBuilder(Material.LOG_2).setDisplayName("&e热带草原").addLore("&7将生物群戏设置为&a热带草原","",(biome!=Biome.SAVANNA?"&e点击选择！":"&a已选择")).build(), e->{
                    RoundManager.getRound().setBiome(Biome.SAVANNA);
                    sendMessage(player,"&a设置完成！");
                    player.closeInventory();
                }));
                contents.set(1,4,ClickableItem.of(new ItemBuilder(Material.ARROW).setDisplayName("&a返回").addLore("&7至领地选项").build(), e->{
                    builder.getParent().open(player);
                }));
            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }
    public static SmartInventory buildBannerColor(ItemStack itemStack){
        SmartInventory.Builder builder=SmartInventory.builder();
        if(itemStack.getType()!=Material.BANNER)return builder.build();
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                int y=0;
                int x=1;
                for (DyeColor value : DyeColor.values()) {
                    if(x==8){
                        x=1;
                        ++y;
                    }
                    contents.set(y,x,ClickableItem.of(new ItemBuilder(Material.INK_SACK).setDyeColor(value).build(),e->{
                        buildBannerPattern(itemStack,value).open(player);
                    }));
                    ++x;
                }
                contents.set(5,3,ClickableItem.of(itemStack,e->{
                    player.closeInventory();
                    player.getInventory().addItem(itemStack);
                }));
                contents.set(5,5,ClickableItem.of(new ItemBuilder(Material.BARRIER).setDisplayName("&c关闭").build(),e->{
                    player.closeInventory();
                }));
            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }

    public static SmartInventory buildBannerPattern(ItemStack stack,DyeColor dyeColor){
        SmartInventory.Builder builder=SmartInventory.builder();
        if(stack.getType()!=Material.BANNER)return builder.build();
        builder.provider(new InventoryProvider() {
            @Override
            public void init(Player player, InventoryContents contents) {
                int y=0;
                int x=0;
                for (PatternType value : PatternType.values()) {
                    if(x==9){
                        x=0;
                        ++y;
                    }
                    contents.set(y,x,ClickableItem.of(new ItemBuilder(Material.BANNER,1, (byte) 0).addPattern(new Pattern(DyeColor.WHITE,value)).addLore("&7点击以添加到旗帜").build(), e->{
                        ItemStack stack1=new ItemBuilder(stack).addPattern(new Pattern(dyeColor,value)).build();
                        buildBannerColor(stack1).open(player);
                    }));
                    ++x;
                }
                contents.set(5,3,ClickableItem.of(stack,e->{
                    player.closeInventory();
                    player.getInventory().addItem(stack);
                }));
                contents.set(5,5,ClickableItem.of(new ItemBuilder(Material.BARRIER).setDisplayName("&c关闭").build(),e->{
                    player.closeInventory();
                }));
            }

            @Override
            public void update(Player player, InventoryContents contents) {

            }
        });
        return builder.build();
    }
    public static void sendMessage(Player player,String... message){
        for (String s : message) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',s));
        }
    }
}
